
select * from librarian;

select * from ViewIssue;
create table issuebook(Bookid varchar(10), Bookno varchar(20), Bookname varchar(30), studentid varchar(30), studentname varchar(30), studentcont varchar(20), bookquantity varchar(5), date varchar(30)); 
select * from issuebook;

create table addbook(Bookid int primary key auto_increment not null, Bookno varchar(50), Bookname varchar(40), author varchar(50), publisher varchar(30), quantity int , issuebook int default 0, date varchar(50));
select * from addbook;