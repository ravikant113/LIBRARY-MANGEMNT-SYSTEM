
package Library;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;

public class ViewIssueBook extends JFrame 
{
    
 String x[]={"Bookid", "Bookno", "Bookname", "studentid", "studentname", "studentcont", "bookquantity", "date"};
 JButton bt;
 String y[][]=new String[20][8];
 int i=0,j=0;
 JTable t;
 Font f,f1;
 
 ViewIssueBook()
 {
         super("IssueBook Information");
          setLocation(1,1);
          setSize(1000,400); 
          
          f=new Font("Arial",Font.BOLD,15);
          
          
          
          try
           {
              ConnectionClass obj=new ConnectionClass();
              String q1="select * from issuebook"; 
              ResultSet res=obj.s.executeQuery(q1);
              while(res.next())
              {
                  
                 // y[i][j++]=res.getString("Lid");
                  y[i][j++]=res.getString("BookID");
                  y[i][j++]=res.getString("BookNo");
                  y[i][j++]=res.getString("Bookname");
                  y[i][j++]=res.getString("studentId");
                  y[i][j++]=res.getString("studentname");
                  y[i][j++]=res.getString("studentcont");
                  y[i][j++]=res.getString("bookquantity");
                  y[i][j++]=res.getString("date");
                  
                  i++;
                  j=0;
              }
              
              t=new JTable(y,x);
              t.setFont(f);
           }
           catch(Exception exx)
           {
               exx.printStackTrace();
           }
          JScrollPane sp=new JScrollPane(t);
            add(sp);
}
 public static void main(String args[])
        {
            new ViewIssueBook().setVisible(true);
        }
}
