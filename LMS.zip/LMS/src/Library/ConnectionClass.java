
package Library;


import java.sql.*;
public class ConnectionClass 
{
    Connection c;
    Statement s;
    
    ConnectionClass()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/Library","root","Password");
            s=c.createStatement();
        }  
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

public static void main(String args[])
{
new ConnectionClass();
}
}
